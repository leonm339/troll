<?php
    $user = 'troll';
    $pass = 'troll';
    $server = 'localhost';
    $db_name = 'troll';
	$db_salt = 'sdhg7432t55$&$%&';
    //povežem se s strežnikom
    $link = mysqli_connect($server, $user, $pass, $db_name);
        
?>